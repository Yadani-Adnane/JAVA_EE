create definer = root@localhost trigger update_etat_batiment
    after update
    on batiment
    for each row
BEGIN
    
    IF OLD.etat <> NEW.etat THEN
        UPDATE etage SET etage.etat = NEW.etat WHERE etage.id_batiment = NEW.id_batiment;
        
    END IF;
END;

