create definer = root@localhost event my_event on schedule
    every '2' MINUTE
        starts '2024-05-10 16:01:51'
    enable
    do
    BEGIN
    CALL check_and_add_reservation();
END;

