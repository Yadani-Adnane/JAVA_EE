create
    definer = root@localhost procedure check_and_add_reservation()
BEGIN
    DECLARE done BOOLEAN DEFAULT FALSE;
    DECLARE r VARCHAR(50);
    DECLARE n int;
    DECLARE id_ch VARCHAR(50);
    DECLARE id VARCHAR(50);
    DECLARE cur CURSOR FOR SELECT id_residant FROM residant;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO r;
        IF done THEN
            LEAVE read_loop;
        END IF;
        SELECT id_chambre,reservationNonPayees INTO id_ch,n FROM residant WHERE id_residant = r LIMIT 1;
            INSERT INTO reservation (date_reservation,frais_de_reservation,id_chambre,id_residant) VALUES (NOW(),600,id_ch,r);
            UPDATE	residant SET reservationNonPayees = (n+1) WHERE id_residant = r;
    END LOOP;
    CLOSE cur;
END;

