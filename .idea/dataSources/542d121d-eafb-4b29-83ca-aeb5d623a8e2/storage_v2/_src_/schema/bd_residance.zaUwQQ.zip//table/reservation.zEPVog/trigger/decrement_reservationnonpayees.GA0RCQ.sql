create definer = root@localhost trigger decrement_reservationNonPayees
    after update
    on reservation
    for each row
BEGIN
    IF NEW.payee <> OLD.payee THEN
        UPDATE residant
        SET reservationNonPayees = reservationNonPayees - 1
        WHERE id_residant = NEW.id_residant;
    END IF;
END;

