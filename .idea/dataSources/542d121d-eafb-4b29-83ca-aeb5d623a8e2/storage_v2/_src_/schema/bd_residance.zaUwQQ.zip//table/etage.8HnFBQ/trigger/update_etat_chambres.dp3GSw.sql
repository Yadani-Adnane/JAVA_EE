create definer = root@localhost trigger ` update_etat_chambres`
    after update
    on etage
    for each row
    IF OLD.etat <> NEW.etat THEN
        UPDATE chambre SET chambre.etat = NEW.etat WHERE chambre.id_etage = NEW.id_etage;
        
END IF;

