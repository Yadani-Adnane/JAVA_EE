create definer = root@localhost trigger update_genre_chambre
    after update
    on etage
    for each row
BEGIN
    IF OLD.id_etage <> NEW.id_etage THEN
        UPDATE chambre SET chambre.id_chambre = CONCAT(NEW.id_etage,'C',chambre.num) WHERE chambre.id_etage = NEW.id_etage;
    END IF;
END;

