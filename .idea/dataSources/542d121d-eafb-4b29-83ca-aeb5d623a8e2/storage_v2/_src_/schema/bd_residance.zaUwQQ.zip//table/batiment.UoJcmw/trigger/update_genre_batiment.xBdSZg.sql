create definer = root@localhost trigger update_genre_batiment
    after update
    on batiment
    for each row
BEGIN
    IF OLD.genre <> NEW.genre THEN
        UPDATE etage SET etage.id_etage = CONCAT(etage.id_batiment,'E',etage.num) WHERE etage.id_batiment = NEW.id_batiment;
    END IF;
END;

