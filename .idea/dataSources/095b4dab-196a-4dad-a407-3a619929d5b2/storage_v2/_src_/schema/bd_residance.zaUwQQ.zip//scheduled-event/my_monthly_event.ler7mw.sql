create definer = root@localhost event my_monthly_event on schedule
    every '1' MONTH
        starts '2024-05-10 16:00:50'
    enable
    do
    BEGIN
    CALL check_and_add_reservation();
END;

