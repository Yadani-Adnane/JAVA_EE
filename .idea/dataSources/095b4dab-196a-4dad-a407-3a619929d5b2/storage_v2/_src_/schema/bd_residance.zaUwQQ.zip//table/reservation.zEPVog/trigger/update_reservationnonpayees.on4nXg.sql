create definer = root@localhost trigger update_reservationNonPayees
    after delete
    on reservation
    for each row
BEGIN
    UPDATE residant
    SET reservationNonPayees = reservationNonPayees - 1
    WHERE id_residant = OLD.id_residant;
END;

